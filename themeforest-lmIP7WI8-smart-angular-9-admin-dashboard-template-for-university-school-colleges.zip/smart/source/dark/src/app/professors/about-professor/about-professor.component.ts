import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-about-professor',
  templateUrl: './about-professor.component.html',
  styleUrls: ['./about-professor.component.sass']
})
export class AboutProfessorComponent implements OnInit {
  constructor() {}
  ngOnInit(): void {}
}
